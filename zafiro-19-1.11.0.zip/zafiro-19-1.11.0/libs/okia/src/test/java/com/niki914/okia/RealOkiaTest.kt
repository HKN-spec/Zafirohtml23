package com.niki914.okia

import com.niki914.okia.conversation.JsonSessionCodec
import com.niki914.okia.conversation.SessionSnapshot
import com.niki914.okia.error.LLMErrorCode
import com.niki914.okia.error.RetryPolicy
import com.niki914.okia.event.StopCause
import com.niki914.okia.event.TurnEvent
import com.niki914.okia.fake.FakeAgentLoop
import com.niki914.okia.fake.FakeHttpEngine
import com.niki914.okia.fake.FakeProtocolMapper
import com.niki914.okia.fake.StubMcpClient
import com.niki914.okia.loop.AgentLoop
import com.niki914.okia.loop.CompletionReason
import com.niki914.okia.loop.LoopOptions
import com.niki914.okia.loop.LoopRequest
import com.niki914.okia.loop.RealAgentLoop
import com.niki914.okia.loop.TurnResult
import com.niki914.okia.message.AssistantMessage
import com.niki914.okia.message.ContentBlock
import com.niki914.okia.message.Message
import com.niki914.okia.message.StopReason
import com.niki914.okia.protocol.ProtocolCompatMapper
import com.niki914.okia.protocol.ProtocolEvent
import com.niki914.okia.transport.HttpEngine
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class RealOkiaTest {

    // ── fixtures ───────────────────────────────────────────────────────────

    private fun user(text: String) = Message.User(listOf(ContentBlock.Text(text)))

    private fun textOf(message: AssistantMessage): String =
        (message.content.single() as ContentBlock.Text).text

    private fun completed(stopReason: StopReason? = StopReason.Stop) =
        ProtocolEvent.Completed(stopReason = stopReason)

    private fun deps(
        mapper: ProtocolCompatMapper,
        loop: AgentLoop = RealAgentLoop(),
        engine: HttpEngine = FakeHttpEngine()
    ) = object : OkiaDependencies {
        override val agentLoop = loop
        override val protocolMapper = mapper
        override val mcpClient = StubMcpClient
    }

    private fun openOkia(
        mapper: ProtocolCompatMapper,
        engine: HttpEngine = FakeHttpEngine(),
        loop: AgentLoop = RealAgentLoop(),
        restore: SessionSnapshot? = null,
        scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
        config: OkiaConfig.Builder.() -> Unit = {}
    ): RealOkia = RealOkia(
        dependencies = deps(mapper, loop, engine),
        restore = restore,
        initialConfig = OkiaConfig.Builder().apply {
            endpoint = "https://api.test/v1"
            apiKey = "test-key"
            model = "test-model"
            httpEngine = engine
        }.apply(config).build(),
        turnScope = scope
    )

    private fun testScope(scheduler: kotlinx.coroutines.test.TestCoroutineScheduler): CoroutineScope =
        CoroutineScope(SupervisorJob() + StandardTestDispatcher(scheduler))

    // ── 初始状态 ───────────────────────────────────────────────────────────

    // ── send 正常路径 ──────────────────────────────────────────────────────

    @Test
    fun sendOnEventExceptionFailsWithHookFailedWithoutRetry() = runTest {
        // 业务 onEvent 在 TextDelta 抛异常（完整链路，经 RealOkia.handleEvent
        // 包装为 CallbackException）：分类为 HookFailed（不可重试）——不伪装成
        // Transport；即使配置回合层重试也不重发请求（问题 1）
        val engine = FakeHttpEngine()
        val okia = openOkia(
            FakeProtocolMapper(
                listOf(ProtocolEvent.TextDelta("a"), ProtocolEvent.TextDelta("b"), completed())
            ),
            engine = engine,
            scope = testScope(testScheduler)
        )
        val result = okia.send(
            "hi",
            options = TurnOptions(
                loopOptions = LoopOptions(
                    turnRetryPolicy = RetryPolicy(
                        maxAttempts = 3
                    )
                )
            )
        ) { event ->
            if (event is TurnEvent.TextDelta) throw IllegalStateException("ui boom")
        }

        val failed = result as TurnResult.Failed
        assertEquals(LLMErrorCode.HookFailed, failed.error.code)
        assertEquals(1, engine.streamedRequests.size) // 不重发
        okia.close()
    }

    @Test
    fun sendCompletedCommitsUserAndAssistant() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(listOf(ProtocolEvent.TextDelta("hello"), completed())),
            scope = testScope(testScheduler)
        )
        val result = okia.send("hi") { }

        assertEquals(TurnResult.Completed(CompletionReason.Stop), result)
        val history = okia.conversation.value.history
        assertEquals(2, history.size)
        assertEquals(user("hi"), history[0].message)
        val assistant = history[1].message as Message.Assistant
        assertEquals("hello", textOf(assistant.message))
        assertNull(okia.conversation.value.live)
        okia.close()
    }

    @Test
    fun sendEmitsFullEventSequence() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(
                listOf(
                    ProtocolEvent.TextDelta("hel"),
                    ProtocolEvent.TextDelta("lo"),
                    completed()
                )
            ),
            scope = testScope(testScheduler)
        )
        val emitted = mutableListOf<TurnEvent>()
        okia.send("hi") { emitted += it }

        assertEquals(TurnEvent.TurnStarted("hi"), emitted[0])
        assertEquals(0, (emitted[1] as TurnEvent.TextStarted).index)
        assertEquals("lo", (emitted[2] as TurnEvent.TextDelta).delta)
        assertTrue(emitted[4] is TurnEvent.TurnCompleted)
        assertEquals(5, emitted.size)
        okia.close()
    }

    @Test
    fun eventsFlowDeliversEvents() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(
                listOf(
                    ProtocolEvent.TextDelta("hel"),
                    ProtocolEvent.TextDelta("lo"),
                    completed()
                )
            ),
            scope = testScope(testScheduler)
        )
        val received = mutableListOf<TurnEvent>()
        val collector = launch { okia.events.collect { received += it } }
        runCurrent()

        okia.send("hi") { }

        assertEquals(5, received.size)
        assertTrue(received.last() is TurnEvent.TurnCompleted)
        collector.cancel()
        okia.close()
    }

    @Test
    fun liveUpdatesDuringStreamingAndClearsOnCommit() = runTest {
        val events = MutableSharedFlow<ProtocolEvent>(extraBufferCapacity = 16)
        val okia = openOkia(FakeProtocolMapper(events), scope = testScope(testScheduler))
        val sendJob = launch { okia.send("hi") { } }
        runCurrent()

        events.emit(ProtocolEvent.TextDelta("hel"))
        runCurrent()
        assertEquals("hel", textOf(okia.conversation.value.live!!))
        assertEquals(1, okia.conversation.value.history.size) // 流式期间 history 不提前更新

        events.emit(ProtocolEvent.TextDelta("lo"))
        runCurrent()
        assertEquals("hello", textOf(okia.conversation.value.live!!))

        events.emit(completed())
        runCurrent()
        assertNull(okia.conversation.value.live)
        assertEquals(2, okia.conversation.value.history.size)

        sendJob.join()
        okia.close()
    }

    // ── send 失败路径 ──────────────────────────────────────────────────────

    @Test
    fun sendFailedWithoutPartialKeepsUserOnly() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(listOf(ProtocolEvent.Error(RuntimeException("boom")))),
            scope = testScope(testScheduler)
        )
        val result = okia.send("hi") { }

        assertTrue(result is TurnResult.Failed)
        assertEquals(1, okia.conversation.value.history.size)
        assertEquals(user("hi"), okia.conversation.value.history[0].message)
        assertNull(okia.conversation.value.live)
        okia.close()
    }

    @Test
    fun sendFailedWithPartialCommitsPartial() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(
                listOf(
                    ProtocolEvent.TextDelta("par"),
                    ProtocolEvent.Error(RuntimeException("boom"))
                )
            ),
            scope = testScope(testScheduler)
        )
        val result = okia.send("hi") { }

        assertTrue(result is TurnResult.Failed)
        val history = okia.conversation.value.history
        assertEquals(2, history.size)
        assertEquals("par", textOf((history[1].message as Message.Assistant).message))
        assertNull(okia.conversation.value.live)
        okia.close()
    }

    // ── 并发契约 ───────────────────────────────────────────────────────────

    @Test
    fun concurrentSendsReserveExactlyOneActiveTurn() = runBlocking {
        // 回归守卫（T2 竞态）：check 与回合状态预留必须在同一临界区——多线程并发
        // send 恰好一个成功、其余抛 IllegalStateException。此前实现 check 通过后
        // 释放锁、append 完成才设置 activeTurn，多个 send 可同时通过（真实线程
        // 交错复现：双 loop、双 User 消息、turnStartEntryId 被覆盖）。
        val gate = CompletableDeferred<Unit>()
        val loop = FakeAgentLoop { _, _ ->
            gate.await()
            TurnResult.Completed(CompletionReason.Stop)
        }
        val okia = openOkia(
            FakeProtocolMapper(listOf(completed())),
            loop = loop
            // 默认 scope = Dispatchers.Default（真实线程池，允许并发交错）
        )
        // 屏障：全部 24 个 send 实际发起后，等待 23 个败者（抛异常）落定——
        // 胜者此时必然仍阻塞在 gate（回合还活跃），再放行 gate。不依赖时间窗口。
        val allStarted = java.util.concurrent.CountDownLatch(24)
        val attempts = (1..24).map { n ->
            async(Dispatchers.Default) {
                allStarted.countDown()
                runCatching { okia.send("t$n") { } }
            }
        }
        allStarted.await()
        val deadline = System.currentTimeMillis() + 10_000
        while (attempts.count { it.isCompleted } < 23 && System.currentTimeMillis() < deadline) {
            delay(1)
        }
        assertTrue(
            "24 个 send 中应有 23 个败者先落定（胜者阻塞在 gate）",
            attempts.count { it.isCompleted } >= 23
        )
        gate.complete(Unit)
        val outcomes = attempts.awaitAll()
        assertEquals(24, outcomes.size)
        assertEquals(1, outcomes.count { it.isSuccess })
        assertEquals(23, outcomes.count { it.exceptionOrNull() is IllegalStateException })
        okia.close()
    }

    @Test
    fun mutationAttemptsInsideTurnAbortedCallbackAreRejected() = runTest {
        // 回归守卫（T2）：Aborted 终态事件派发期间门面仍处于活跃回合——回调内的
        // rewind 不得通过（此前 activeTurn 在事件派发前已被 job finally 清空，
        // 回调内可插入 mutation，且其 live=null 会冲掉下一回合的 live）。
        val events = MutableSharedFlow<ProtocolEvent>(extraBufferCapacity = 16)
        val okia = openOkia(FakeProtocolMapper(events), scope = testScope(testScheduler))
        var rewindResult: Result<Unit>? = null
        val job = launch {
            okia.send("one") { event ->
                if (event is TurnEvent.TurnAborted) {
                    rewindResult = runCatching { okia.rewind("x") }
                }
            }
        }
        runCurrent()
        okia.stop()
        job.join()
        val result = rewindResult ?: error("TurnAborted callback never ran")
        assertTrue(result.exceptionOrNull() is IllegalStateException)
        okia.close()
    }

    @Test
    fun mutationDuringActiveTurnThrows() = runTest {
        val events = MutableSharedFlow<ProtocolEvent>(extraBufferCapacity = 16)
        val okia = openOkia(FakeProtocolMapper(events), scope = testScope(testScheduler))
        val first = launch { okia.send("one") { } }
        runCurrent()

        assertNotNull(
            try {
                okia.rewind("x"); null
            } catch (e: IllegalStateException) {
                e
            }
        )
        assertNotNull(
            try {
                okia.update { }; null
            } catch (e: IllegalStateException) {
                e
            }
        )
        assertNotNull(
            try {
                okia.export(); null
            } catch (e: IllegalStateException) {
                e
            }
        )
        assertNotNull(
            try {
                okia.close(); null
            } catch (e: IllegalStateException) {
                e
            }
        )

        first.cancel()
        runCurrent() // 让 turn job 清理 activeTurn
        okia.close()
    }

    @Test
    fun serialSendsWork() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(listOf(completed())),
            scope = testScope(testScheduler)
        )
        assertEquals(TurnResult.Completed(CompletionReason.Stop), okia.send("one") { })
        assertEquals(TurnResult.Completed(CompletionReason.Stop), okia.send("two") { })
        assertEquals(4, okia.conversation.value.history.size)
        okia.close()
    }

    // ── stop 契约 ──────────────────────────────────────────────────────────

    @Test
    fun stopAbortsAndCommitsPartial() = runTest {
        val events = MutableSharedFlow<ProtocolEvent>(extraBufferCapacity = 16)
        val okia = openOkia(FakeProtocolMapper(events), scope = testScope(testScheduler))
        val result = async { okia.send("hi") { } }
        runCurrent()

        events.emit(ProtocolEvent.TextDelta("par"))
        runCurrent()
        okia.stop()

        assertEquals(TurnResult.Aborted(StopCause.UserStop), result.await())
        val history = okia.conversation.value.history
        assertEquals(2, history.size)
        assertEquals("par", textOf((history[1].message as Message.Assistant).message))
        assertNull(okia.conversation.value.live)
        okia.close()
    }

    // （stop 无活跃回合 / stop 后立刻再 send / 外部取消传播：由 RealOkiaStopTest
    //  的 stopWithNoActiveTurnIsNoOp、stopThenSendStartsFreshTurn、
    //  externalCancellationTriggersBeforeStopAndRethrows 覆盖，此处不重复）

    // ── 会话操作 ───────────────────────────────────────────────────────────

    @Test
    fun rewindMovesLeafAndValidatesEntry() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(listOf(completed())),
            scope = testScope(testScheduler)
        )
        okia.send("hi") { }
        val userEntry = okia.conversation.value.history[0]

        okia.rewind(userEntry.id)
        assertEquals(listOf(user("hi")), okia.conversation.value.history.map { it.message })

        assertNotNull(
            try {
                okia.rewind("missing"); null
            } catch (e: IllegalArgumentException) {
                e
            }
        )
        okia.close()
    }

    @Test
    fun exportRestoreRoundTrip() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(listOf(ProtocolEvent.TextDelta("hello"), completed())),
            scope = testScope(testScheduler)
        )
        okia.send("hi") { }
        val snapshot = okia.export()

        val raw = JsonSessionCodec().encode(snapshot)
        val decoded = JsonSessionCodec().decode(raw)

        val restored = openOkia(
            FakeProtocolMapper(emptyList<ProtocolEvent>()),
            restore = decoded,
            scope = testScope(testScheduler)
        )
        assertEquals(okia.conversation.value.history, restored.conversation.value.history)
        assertEquals(okia.conversation.value.leafId, restored.conversation.value.leafId)

        okia.close()
        restored.close()
    }

    @Test
    fun updateReplacesConfigSnapshot() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(emptyList<ProtocolEvent>()),
            scope = testScope(testScheduler)
        )
        val before = okia.config()
        val hook = object : com.niki914.okia.hooks.Hooks {}

        okia.update {
            model = "new-model"
            hooks = listOf(hook)
        }
        val after = okia.config()

        assertEquals("new-model", after.model)
        assertEquals(listOf<Any>(hook), after.hooks)
        assertEquals(before.endpoint, after.endpoint)
        assertEquals(before.apiKey, after.apiKey)
        okia.close()
    }

    @Test
    fun closeThenAllOperationsThrow() = runTest {
        val okia = openOkia(
            FakeProtocolMapper(emptyList<ProtocolEvent>()),
            scope = testScope(testScheduler)
        )
        okia.close()

        assertNotNull(
            try {
                okia.send("hi") { }; null
            } catch (e: IllegalStateException) {
                e
            }
        )
        assertNotNull(
            try {
                okia.rewind("x"); null
            } catch (e: IllegalStateException) {
                e
            }
        )
        assertNotNull(
            try {
                okia.update { }; null
            } catch (e: IllegalStateException) {
                e
            }
        )
        assertNotNull(
            try {
                okia.export(); null
            } catch (e: IllegalStateException) {
                e
            }
        )
        assertNotNull(
            try {
                okia.close(); null
            } catch (e: IllegalStateException) {
                e
            }
        )
    }

    @Test
    fun agentLoopReceivesRequestWithHistoryAndOptions() = runTest {
        var received: LoopRequest? = null
        val loop = FakeAgentLoop { request, _ ->
            received = request
            TurnResult.Completed(CompletionReason.Stop)
        }
        val okia = openOkia(
            FakeProtocolMapper(emptyList<ProtocolEvent>()),
            loop = loop,
            scope = testScope(testScheduler)
        )
        okia.send("hi", options = TurnOptions(systemPrompt = "sys", model = "override-model")) { }

        val request = received!!
        assertEquals("hi", request.input)
        assertEquals("override-model", request.snapshot.model)
        assertEquals("sys", request.snapshot.systemPrompt)
        assertEquals(listOf(user("hi")), request.history) // history 已含当前输入
        okia.close()
    }
}
